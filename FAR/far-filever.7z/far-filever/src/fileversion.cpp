﻿/**
	filever: File Version FAR plugin
	Displays version information from file resource in dialog
	FAR3 plugin

	© 2013 Andrew Grechkin

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
**/

#include "fileversion.hpp"

#include <system/cstr.hpp>
#include <system/memory.hpp>
#include <system/fsys.hpp>
#include <system/logger.hpp>
#include <system/totext.hpp>

#include <simstd/string>

#include <stdio.h>

#define NTSIGNATURE(a) ((LPVOID)((BYTE *)(a) + ((PIMAGE_DOS_HEADER)(a))->e_lfanew))

WINBOOL EnumResLangProc(HMODULE module, PCWSTR lpType, PCWSTR lpName, WORD language, LONG_PTR param)
{
	HRSRC hResInfo = ::FindResourceExW(module, lpType, lpName, language);

	LogDebug(L"\t\tLanguage: 0x%X, param: 0x%X\n", language, param);

	LogDebug(L"\t\thResInfo == %p,  Size == 0x%X\r\n\r\n", hResInfo, SizeofResource(module, hResInfo));

	HGLOBAL rc = ::LoadResource(module, hResInfo);

	PVOID ptr = LockResource(rc);

	LogDebug(L"%S\n", (PCSTR)ptr);

	return TRUE;
}

WINBOOL EnumResNameProc(HMODULE module, PCWSTR lpType, PWSTR lpName, LONG_PTR)
{
	LogDebug(L"\tType: %p Name: %p\n", lpType, lpName);

	if (!IS_INTRESOURCE(lpName)) {
		LogDebug(L"\tName: '%s'\n", lpName);
	} else {
		LogDebug(L"\tName: %Iu\n", reinterpret_cast<size_t>(lpName));
	}

	::EnumResourceLanguagesW(module, lpType, lpName, EnumResLangProc, 0);

	return TRUE;
}

WINBOOL EnumResTypeProc(HMODULE module, PWSTR lpType, LONG_PTR)
{
	if (!IS_INTRESOURCE(lpType)) {
		LogDebug(L"Type: '%s'\n", lpType);
	} else {
		LogDebug(L"Type: %Iu\n", reinterpret_cast<size_t>(lpType));
	}

	::EnumResourceNamesW(module, lpType, EnumResNameProc, 0);

	return TRUE;
}

version_dll & version_dll::inst()
{
	static version_dll ret;
	return ret;
}

bool version_dll::is_valid() const
{
	return DynamicLibrary::is_valid() && GetFileVersionInfoSizeW && VerLanguageNameW && GetFileVersionInfoW && VerQueryValueW;
}

version_dll::version_dll() :
	DynamicLibrary(L"version.dll")
{
	GET_DLL_FUNC(GetFileVersionInfoSizeW);
	GET_DLL_FUNC(VerLanguageNameW);
	GET_DLL_FUNC(GetFileVersionInfoW);
	GET_DLL_FUNC(VerQueryValueW);
}

FileVersion::~FileVersion()
{
	memory::free(m_data);
}

FileVersion::FileVersion(PCWSTR path) :
	m_data(nullptr)
{
	LogDebug(L"path: '%s'\n", path);
	memory::zero(this, sizeof(*this));

	fsys::File::Map_nt fmap(path, sizeof(IMAGE_DOS_HEADER));
	if (fmap.is_ok() && (fmap.size() == sizeof(IMAGE_DOS_HEADER))) {
		PIMAGE_DOS_HEADER dosHeader = (PIMAGE_DOS_HEADER)fmap.data();
		if (dosHeader->e_magic != IMAGE_DOS_SIGNATURE) {
			return;
		}
		PIMAGE_NT_HEADERS pPEHeader = (PIMAGE_NT_HEADERS)NTSIGNATURE(dosHeader);

		if (pPEHeader->Signature != IMAGE_NT_SIGNATURE) {
			return;
		}
		m_machine = pPEHeader->FileHeader.Machine;
		m_flags =   pPEHeader->FileHeader.Characteristics;
		m_created = pPEHeader->FileHeader.TimeDateStamp;
	}

	DWORD hndl = 0;
	DWORD size = version_dll::inst().GetFileVersionInfoSizeW(path, &hndl);
	LogDebug(L"size: %u\n", size);
	LogDebug(L"hndl: %u\n", hndl);

	if (size && memory::realloc(m_data, size) && version_dll::inst().GetFileVersionInfoW(path, hndl, size, m_data)) {
		UINT buf_len;
		VS_FIXEDFILEINFO * ffi;
		if (version_dll::inst().VerQueryValueW(m_data, (PWSTR)L"\\", reinterpret_cast<void **>(&ffi), &buf_len)) {
			m_MajorVersion = HIWORD(ffi->dwFileVersionMS);
			m_MinorVersion = LOWORD(ffi->dwFileVersionMS);
			m_BuildNumber = HIWORD(ffi->dwFileVersionLS);
			m_RevisionNumber = LOWORD(ffi->dwFileVersionLS);
			_snwprintf(m_ver, lengthof(m_ver), L"%d.%d.%d.%d", m_MajorVersion, m_MinorVersion, m_BuildNumber, m_RevisionNumber);
			LogDebug(L"ver: '%s'\n", m_ver);
		}

		struct LANGANDCODEPAGE {
			WORD wLanguage;
			WORD wCodePage;
		}* translate;

		bool res = version_dll::inst().VerQueryValueW(m_data, (PWSTR)L"VarFileInfo\\Translation", reinterpret_cast<void **>(&translate), &buf_len);
		LogErrorIf(!res, L"%s -> %s\n", L"\\VarFileInfo\\Translation", totext::api_error().c_str());
		LogDebugIf(res,  L"%s -> (%u, %u)\n", L"\\VarFileInfo\\Translation", translate->wLanguage, translate->wCodePage);

		if (res) {
			safe_snprintf(m_lngId, lengthof(m_lngId), L"%04x%04x", translate->wLanguage, translate->wCodePage);
			WCHAR tmp[4] = {0};
			DWORD err = 0;
			safe_snprintf(tmp, lengthof(tmp), L"%04x", translate->wCodePage);
			err = cstr::to_uint32(tmp);
			safe_snprintf(m_lngIderr, lengthof(m_lngIderr), L"%04x%04x", translate->wLanguage, err);

			res = version_dll::inst().VerLanguageNameW(translate->wLanguage, m_lng, lengthof(m_lng));
			LogErrorIf(!res, L"VerLanguageName -> %s\n", totext::api_error().c_str());
			LogDebugIf(res,  L"VerLanguageName -> %s\n", m_lng);
		}

		HMODULE module = ::LoadLibraryExW(path, nullptr, LOAD_LIBRARY_AS_IMAGE_RESOURCE);
		LogErrorIf(!module, L"LoadLibraryW -> %s\n", totext::api_error().c_str());
		LogDebugIf(module,  L"LoadLibraryW -> %p\n", module);

		if (module) {
			::EnumResourceTypesW(module, EnumResTypeProc, 0);
		}
	}
}

FVI::FVI(const FileVersion & in)
{
	FileVerInfo_ tmp[] = {
		{L"", L"FileDescription", MtxtFileDesc},
		{L"", L"LegalCopyright", MtxtFileCopyright},
		{L"", L"Comments", MtxtFileComment},
		{L"", L"CompanyName", MtxtFileCompany},
		{L"", L"FileVersion", MtxtFileVer},
		{L"", L"InternalName", MtxtFileInternal},
		{L"", L"LegalTrademarks", MtxtFileTrade},
		{L"", L"OriginalFilename", MtxtFileOriginal},
		{L"", L"PrivateBuild", MtxtFilePrivate},
		{L"", L"ProductName", MtxtFileProductName},
		{L"", L"ProductVersion", MtxtFileProductVer},
		{L"", L"SpecialBuild", MtxtFileSpecial},
	};
	this->m_data = tmp;
	this->m_size = lengthof(tmp);

	if (in.is_version_loaded()) {
		WCHAR QueryString[128] = {0};
		UINT bufLen;
		for (size_t i = 0; i < m_size; ++i) {
			_snwprintf(QueryString, lengthof(QueryString), L"\\StringFileInfo\\%s\\%s", in.lngID(), m_data[i].SubBlock);
			if (!version_dll::inst().VerQueryValueW(in.GetData(), QueryString, (void **)(&m_data[i].data), &bufLen)) {
				_snwprintf(QueryString, lengthof(QueryString), L"\\StringFileInfo\\%s\\%s", in.lngIDerr(), m_data[i].SubBlock);
				if (!version_dll::inst().VerQueryValueW(in.GetData(), QueryString, (void **)(&m_data[i].data), &bufLen)) {
					m_data[i].data = L"";
					LogError(L"'%s' -> %d\n", QueryString, ::GetLastError());
				} else {
					LogError(L"'%s' -> '%s'\n", QueryString, m_data[i].data);
				}
			}
		}
	} else {
		LogError(L"Version not loaded\n");
	}
}
